#pragma once

namespace CppCliWinForm
{
   /// <summary>
   /// Summary for Form1
   /// </summary>
   public ref class Form1 : public System::Windows::Forms::Form
   {
   public:
     Form1(void);

   protected:
      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
     ~Form1();

   private:
      /// <summary>
      /// Required designer variable.
      /// </summary>
      System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      void InitializeComponent(void);
#pragma endregion
   };
}
